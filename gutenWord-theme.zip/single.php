<?php
/**
 * The template for displaying the posts
 *
 * @package GutenWord
 * @since 1.0.0
 */
?>
<?php get_header(); ?>
	<div class="container">
		<?php
			/*
			Get the activate template 
			Set the single style for this template
			*/
		?>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>
		