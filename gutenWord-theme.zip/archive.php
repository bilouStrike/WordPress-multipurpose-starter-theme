<?php
/**
 * The template for displaying the category
 *
 * @package GutenWord
 * @since 1.0.0
 */
?>
<?php get_header(); ?>
	<div class="container">
		<?php
		/*
			post loop for category page
			Get the activate template 
			set loop module (style) for this template 
		*/
		?>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>