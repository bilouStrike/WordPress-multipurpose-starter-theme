<?php

/**
 * all theme configuration data
 */
class gtnw_config 
{
	public static function header_styles()
	{
		return array(
			'Header style 1' => 'header_style_1',
			'Header style 2' => 'header_style_2',
			'Header style Simple' => 'header_style_3'
		);
	}
}

?>