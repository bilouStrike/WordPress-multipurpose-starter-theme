<?php

class gtnw_section {

	public static function the_header_()
	{
		// check activate header style 
	}
	public static function show_the_single()
	{
		// check activate header style
	}
	public static function show_the_footer()
	{
		// check activate footer style
	}
	
}

?>