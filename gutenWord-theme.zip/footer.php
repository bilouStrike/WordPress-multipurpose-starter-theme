<?php
/**
 * The template for displaying the footer
 *
 * @package GutenWord
 * @since 1.0.0
 */
?>
		
		<?php
			/*
			Get the activate template 
			Set the footer style for this template
			*/
		?>
	</body>
</html>