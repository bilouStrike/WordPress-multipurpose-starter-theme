<h2>
	category header section
</h2>
<?php gtnw_helpers::show_category_top_posts(); ?>