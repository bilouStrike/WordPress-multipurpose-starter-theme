<?php
// call the topbar styles
Gtnw_helpers::show_the_topbar(); ?>

