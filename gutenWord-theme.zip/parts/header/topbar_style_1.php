<div class="top-bar">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarText">
        <!-- Left Menu -->
            <?php gtnw_helpers::show_topbar_menu(); ?>
        </div>
        <div class="social-media">
        <!-- Social Media Icons -->
        <?php gtnw_helpers::show_topbar_social_icon(); ?>
        </div>
    </nav>
</div>