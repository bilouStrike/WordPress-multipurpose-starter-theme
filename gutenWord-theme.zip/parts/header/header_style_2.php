<div class="row">
	<div class="col-md-12 bg-gray">Top menu</div>
	<div class="col-md-2 mediem-height bg-red">
		LOGO
	</div>
	<div class="col-md-10 mediem-height bg-gray">
		ADS
	</div>
	<div class="col-md-12 small-height bg-black">
		Main menu
	</div>
</div>
