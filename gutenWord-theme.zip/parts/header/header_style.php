<div class="row">
	<div class="col-md-12 bg-gray">Top menu</div>
	<div class="col-md-2">
		LOGO
	</div>
	<div class="col-md-10">
		ADS
	</div>
</div>