<?php
	global $post;
	
	// Header dynamic section
	gtnw_helpers::the_signle_header();

	// Body (post content) style
	gtnw_helpers::the_signle_body();

	// Footer dynamic section
	gtnw_helpers::the_signle_footer();
	
?>